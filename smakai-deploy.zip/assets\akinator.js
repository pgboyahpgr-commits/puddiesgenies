let allDishes = [];
let probabilities = [];
let askedKeys = new Set();
let currentQ = 0;
let wrongIndex = -1;
let gameOver = false;
let currentMode = 'guess';
let guessConversation = [];

const QUESTIONS = [
  { key: 'veg', q: 'Is it vegetarian?', icon: '🥬', map: function(a) { return a.is_vegetarian === true; } },
  { key: 'spice', q: 'Is it spicy?', icon: '🌶️', map: function(a) { return a.spice_level === 'hot'; } },
  { key: 'type', q: 'Is it a main course dish?', icon: '🍛', map: function(a) { return ['biryani','curries','thali','tandoor','south_indian','rice'].indexOf(a.category_id) >= 0; } },
  { key: 'rice', q: 'Does it have rice or bread?', icon: '🍚', map: function(a) { return ['biryani','breads','south_indian','thali','rice'].indexOf(a.category_id) >= 0 || a.name.toLowerCase().indexOf('rice') >= 0 || a.name.toLowerCase().indexOf('roti') >= 0 || a.name.toLowerCase().indexOf('naan') >= 0; } },
  { key: 'snack', q: 'Is it a snack or appetizer?', icon: '🥟', map: function(a) { return ['appetizers','street_food','snacks','chaat'].indexOf(a.category_id) >= 0; } },
  { key: 'sweet', q: 'Is it a dessert or sweet?', icon: '🍰', map: function(a) { return ['desserts','sweets','beverages'].indexOf(a.category_id) >= 0 || a.spice_level === 'sweet'; } },
  { key: 'chicken', q: 'Is it a chicken dish?', icon: '🐔', map: function(a) { return a.name.toLowerCase().indexOf('chicken') >= 0; } },
  { key: 'mutton', q: 'Is it a lamb or mutton dish?', icon: '🐑', map: function(a) { return a.name.toLowerCase().indexOf('mutton') >= 0 || a.name.toLowerCase().indexOf('lamb') >= 0; } },
  { key: 'price', q: 'Is it under ₹200?', icon: '💰', map: function(a) { return (a.price || 0) < 200; } },
  { key: 'region_north', q: 'Is it from North India?', icon: '🏔️', map: function(a) { return ['North India','Punjab','Mughlai','Kashmir','Rajasthan','Delhi'].indexOf(a.region) >= 0; } },
  { key: 'region_south', q: 'Is it from South India?', icon: '🌴', map: function(a) { return ['South India','Kerala','Tamil Nadu','Hyderabad','Karnataka','Goa','Coastal India'].indexOf(a.region) >= 0; } },
  { key: 'popular', q: 'Is it a popular dish?', icon: '⭐', map: function(a) { return a.popular === true; } },
];

function initAkinator() {
  if (window.__AKINATOR_DISHES && window.__AKINATOR_DISHES.length > 0) {
    allDishes = window.__AKINATOR_DISHES;
    return;
  }
  var cards = document.querySelectorAll('.dish-card, .menu-item');
  if (cards.length > 0) {
    allDishes = Array.from(cards).map(function(c) {
      return {
        name: c.dataset.name || '',
        category_id: c.dataset.cat || '',
        category_name: c.dataset.catName || '',
        is_vegetarian: c.querySelector('.badge-veg') !== null,
        spice_level: c.querySelector('.badge-hot') ? 'hot' : c.querySelector('.badge-medium') ? 'medium' : 'mild',
        price: parseInt(c.dataset.price) || 0,
        region: c.dataset.region || 'North India',
        popular: c.dataset.popular === 'true',
        description: c.dataset.desc || '',
        image: c.dataset.image || ''
      };
    });
  }
}

function switchMode(mode) {
  currentMode = mode;
  document.getElementById('guessMode').style.display = mode === 'guess' ? 'block' : 'none';
  document.getElementById('chatMode').style.display = mode === 'chat' ? 'block' : 'none';

  var guessBtn = document.getElementById('modeGuess');
  var chatBtn = document.getElementById('modeChat');
  if (mode === 'guess') {
    guessBtn.style.background = '#FF6B6B'; guessBtn.style.color = '#fff';
    chatBtn.style.background = 'rgba(255,255,255,0.6)'; chatBtn.style.border = '1px solid #ddd'; chatBtn.style.color = '#2D3436';
    startNewGame();
  } else {
    chatBtn.style.background = '#FF6B6B'; chatBtn.style.color = '#fff';
    guessBtn.style.background = 'rgba(255,255,255,0.6)'; guessBtn.style.border = '1px solid #ddd'; guessBtn.style.color = '#2D3436';
  }
}

function startNewGame() {
  initAkinator();
  if (allDishes.length === 0) return;
  probabilities = allDishes.map(function() { return 1 / allDishes.length; });
  askedKeys = new Set();
  currentQ = 0;
  wrongIndex = -1;
  gameOver = false;
  guessConversation = [];
  var guessBox = document.getElementById('guessBox');
  if (guessBox) guessBox.style.display = 'none';
  var gameArea = document.getElementById('gameArea');
  if (gameArea) {
    var inputs = gameArea.querySelectorAll('button, input');
    for (var i = 0; i < inputs.length; i++) inputs[i].disabled = false;
  }
  var customAnswer = document.getElementById('customAnswer');
  if (customAnswer) customAnswer.value = '';
  var qText = document.getElementById('questionText');
  if (qText) qText.textContent = 'Think of a dish from our menu...';
  var sText = document.getElementById('statusText');
  if (sText) sText.textContent = 'Ready to play!';
  var cList = document.getElementById('candidateList');
  if (cList) cList.innerHTML = '';
  askNext();
}

function askNext() {
  if (gameOver) return;

  // Pick the best question based on remaining candidates
  var available = QUESTIONS.filter(function(q) { return !askedKeys.has(q.key); });

  if (available.length === 0 || currentQ >= 12) { makeGuess(); return; }

  // Score each question by how evenly it splits the candidates
  var scored = available.map(function(q) {
    var yesCount = 0;
    var total = 0;
    for (var i = 0; i < allDishes.length; i++) {
      if (probabilities[i] < 0.01) continue;
      total++;
      if (q.map(allDishes[i])) yesCount++;
    }
    if (total === 0) return { q: q, score: 0 };
    var yesRatio = yesCount / total;
    var noRatio = 1 - yesRatio;
    // Best question splits 50-50 (entropy-based)
    var score = 1 - Math.abs(yesRatio - 0.5) * 2;
    return { q: q, score: score };
  });

  scored.sort(function(a, b) { return b.score - a.score; });
  var best = scored[0].q;

  askedKeys.add(best.key);

  var qText = document.getElementById('questionText');
  if (qText) qText.textContent = best.icon + ' ' + best.q;
  var sText = document.getElementById('statusText');
  if (sText) sText.textContent = 'Question ' + (currentQ + 1) + ' of 12';
  updateCandidates();

  // Store current question for when answer comes
  window.__currentQuestion = best;
}

function handleAnswer(answer) {
  if (gameOver) return;
  var q = window.__currentQuestion;
  if (!q) return;

  var yes = 0;
  if (answer === 'yes') yes = 1;
  else if (answer === 'no') yes = 0;
  else yes = 0.5;

  if (wrongIndex >= 0) {
    probabilities[wrongIndex] = 0;
    wrongIndex = -1;
  }

  // Update probabilities using Bayesian inference
  var newProbs = probabilities.map(function(p, i) {
    var matches = q.map(allDishes[i]);
    var likelihood = matches ? yes : (1 - yes);
    return p * Math.max(likelihood, 0.05);
  });

  var sum = newProbs.reduce(function(a, b) { return a + b; }, 0);
  if (sum > 0) {
    probabilities = newProbs.map(function(p) { return p / sum; });
  } else {
    probabilities = allDishes.map(function() { return 1 / allDishes.length; });
  }

  currentQ++;
  var maxP = Math.max.apply(null, probabilities);

  if (maxP >= 0.75 || currentQ >= 12) {
    makeGuess();
  } else {
    askNext();
  }
  updateCandidates();
}

function makeGuess() {
  var maxP = Math.max.apply(null, probabilities);
  if (maxP <= 0 || isNaN(maxP)) { startNewGame(); return; }
  var idx = probabilities.indexOf(maxP);
  var dish = allDishes[idx];
  if (!dish) return;

  gameOver = true;
  wrongIndex = idx;

  document.getElementById('guessText').textContent = '🍛 ' + dish.name + '!';
  document.getElementById('guessConfidence').textContent = "I'm " + Math.round(maxP * 100) + '% sure this is what you want!';
  document.getElementById('guessDesc').textContent = dish.description || (dish.category_name || '') + ' — ₹' + (dish.price || '?');
  document.getElementById('guessBox').style.display = 'block';
  document.getElementById('questionText').textContent = '🎉 I guessed it!';

  var gameArea = document.getElementById('gameArea');
  if (gameArea) {
    var inputs = gameArea.querySelectorAll('button, input');
    for (var i = 0; i < inputs.length; i++) inputs[i].disabled = true;
  }

  // Set image
  if (dish.image) {
    document.getElementById('guessImageBox').innerHTML = '<img src="' + dish.image + '" alt="' + dish.name + '" class="w-full h-full object-cover" />';
  } else {
    fetch('/includes/image-fetcher.php?dish=' + encodeURIComponent(dish.name))
      .then(function(r) { return r.json(); })
      .then(function(data) {
        if (data && data.url) {
          document.getElementById('guessImageBox').innerHTML = '<img src="' + data.url + '" alt="' + dish.name + '" class="w-full h-full object-cover" />';
        }
      })
      .catch(function() {});
  }
  document.getElementById('guessMenuLink').href = '/menu.php?search=' + encodeURIComponent(dish.name);
}

function updateCandidates() {
  var list = document.getElementById('candidateList');
  if (!list) return;
  var items = probabilities.map(function(p, i) { return { p: p, dish: allDishes[i] }; });
  items.sort(function(a, b) { return b.p - a.p; });
  items = items.slice(0, 5);
  list.innerHTML = items.map(function(item, i) {
    var pct = Math.round(item.p * 100);
    if (pct < 1) return '';
    return '<span class="px-3 py-1 rounded-full text-sm ' + (i === 0 ? 'bg-[#FF6B6B] text-white font-bold' : 'bg-gray-100 text-gray-600') + '">' + item.dish.name + ' (' + pct + '%)</span>';
  }).join('');
}

// ─── AI CHAT MODE ──────────────────────────────────────────────
function aiChatSend() {
  var input = document.getElementById('aiChatInput');
  var text = input.value.trim();
  if (!text) return;

  var container = document.getElementById('aiChatMessages');

  // Add user message
  var userDiv = document.createElement('div');
  userDiv.className = 'flex gap-3 items-start flex-row-reverse';
  userDiv.innerHTML = '<div class="w-8 h-8 rounded-full bg-[#4ECDC4] flex items-center justify-center text-white text-sm font-bold flex-shrink-0">You</div><div class="bg-[#4ECDC4]/10 rounded-2xl rounded-tr-sm px-4 py-3 text-sm max-w-[80%]" style="border:1px solid #ddd;">' + escapeHtml(text) + '</div>';
  container.appendChild(userDiv);

  input.value = '';
  input.disabled = true;
  document.getElementById('aiChatSend').disabled = true;

  // Loading indicator
  var loadingDiv = document.createElement('div');
  loadingDiv.className = 'flex gap-3 items-start';
  loadingDiv.id = 'aiLoading';
  loadingDiv.innerHTML = '<div class="w-8 h-8 rounded-full bg-[#FF6B6B] flex items-center justify-center text-white text-sm font-bold flex-shrink-0">AI</div><div class="bg-white/80 rounded-2xl rounded-tl-sm px-4 py-3 text-sm" style="border:1px solid #eee;"><span class="inline-block animate-pulse">Searching menu...</span></div>';
  container.appendChild(loadingDiv);
  container.scrollTop = container.scrollHeight;

  fetch('/api/ai-recommend.php', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ message: text, mode: 'recommend' })
  })
  .then(function(r) { return r.json(); })
  .then(function(data) {
    var loading = document.getElementById('aiLoading');
    if (loading) loading.remove();

    if (data.success) {
      // Show AI text message
      if (data.text) {
        var textDiv = document.createElement('div');
        textDiv.className = 'flex gap-3 items-start';
        textDiv.innerHTML = '<div class="w-8 h-8 rounded-full bg-[#FF6B6B] flex items-center justify-center text-white text-sm font-bold flex-shrink-0">AI</div>'
          + '<div class="bg-white/80 rounded-2xl rounded-tl-sm px-4 py-3 text-sm max-w-[80%]" style="border:1px solid #eee;">'
          + escapeHtml(data.text) + '</div>';
        container.appendChild(textDiv);
      }

      // Show dish cards
      if (data.dishes && data.dishes.length > 0) {
        var cardsDiv = document.createElement('div');
        cardsDiv.className = 'flex gap-3 items-start';
        cardsDiv.innerHTML = '<div class="w-8 h-8 rounded-full bg-[#FF6B6B] flex items-center justify-center text-white text-sm font-bold flex-shrink-0">AI</div>'
          + '<div class="flex-1 space-y-2">'
          + data.dishes.map(function(d) { return renderDishCard(d); }).join('')
          + '</div>';
        container.appendChild(cardsDiv);
      } else if (!data.text) {
        // Fallback: show raw response
        var fallbackDiv = document.createElement('div');
        fallbackDiv.className = 'flex gap-3 items-start';
        fallbackDiv.innerHTML = '<div class="w-8 h-8 rounded-full bg-[#FF6B6B] flex items-center justify-center text-white text-sm font-bold flex-shrink-0">AI</div>'
          + '<div class="bg-white/80 rounded-2xl rounded-tl-sm px-4 py-3 text-sm max-w-[80%]" style="border:1px solid #eee;">'
          + (data.response || 'No results found.').replace(/\n/g, '<br>') + '</div>';
        container.appendChild(fallbackDiv);
      }
    } else {
      var errDiv = document.createElement('div');
      errDiv.className = 'flex gap-3 items-start';
      errDiv.innerHTML = '<div class="w-8 h-8 rounded-full bg-[#FF6B6B] flex items-center justify-center text-white text-sm font-bold flex-shrink-0">AI</div>'
        + '<div class="bg-white/80 rounded-2xl rounded-tl-sm px-4 py-3 text-sm max-w-[80%]" style="border:1px solid #eee;color:#FF6B6B;">'
        + 'Sorry, I couldn\'t process that. Try asking about a specific dish or ingredient!</div>';
      container.appendChild(errDiv);
    }
    container.scrollTop = container.scrollHeight;
  })
  .catch(function() {
    var loading = document.getElementById('aiLoading');
    if (loading) loading.remove();
    var errDiv = document.createElement('div');
    errDiv.className = 'flex gap-3 items-start';
    errDiv.innerHTML = '<div class="w-8 h-8 rounded-full bg-[#FF6B6B] flex items-center justify-center text-white text-sm font-bold flex-shrink-0">AI</div>'
      + '<div class="bg-white/80 rounded-2xl rounded-tl-sm px-4 py-3 text-sm max-w-[80%]" style="border:1px solid #eee;color:#FF6B6B;">'
      + 'Network error. Please try again.</div>';
    container.appendChild(errDiv);
    container.scrollTop = container.scrollHeight;
  })
  .then(function() {
    input.disabled = false;
    document.getElementById('aiChatSend').disabled = false;
    input.focus();
  });
}

function renderDishCard(d) {
  var img = d.image ? '<img src="' + escapeHtml(d.image) + '" alt="' + escapeHtml(d.name) + '" class="w-full h-full object-cover" />' : '🍽️';
  var vegTag = d.is_vegetarian ? '🥬 Veg' : '🍗 Non-Veg';
  var popTag = d.popular ? '<span class="text-xs bg-yellow-100 text-yellow-700 px-2 py-0.5 rounded-full">⭐ Popular</span>' : '';
  return '<div class="dish-result-card" onclick="window.location.href=\'/menu.php?search=' + encodeURIComponent(d.name) + '\'">'
    + '<div class="dish-result-img">' + img + '</div>'
    + '<div class="dish-result-info">'
    + '<div class="dish-result-name">' + escapeHtml(d.name) + ' ' + popTag + '</div>'
    + '<div class="dish-result-meta">' + vegTag + ' · ₹' + d.price + ' · ' + escapeHtml(d.region || '') + ' · 🌶️ ' + escapeHtml(d.spice_level || '') + '</div>'
    + (d.description ? '<div class="dish-result-desc">' + escapeHtml(d.description) + '</div>' : '')
    + '<div class="dish-result-cat">' + escapeHtml(d.category || '') + '</div>'
    + '</div>'
    + '</div>';
}

function escapeHtml(str) {
  if (!str) return '';
  return str.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

// ─── EVENT BINDINGS ────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', function() {
  initAkinator();

  document.getElementById('modeGuess')?.addEventListener('click', function() { switchMode('guess'); });
  document.getElementById('modeChat')?.addEventListener('click', function() { switchMode('chat'); });

  document.getElementById('resetBtn')?.addEventListener('click', startNewGame);
  document.getElementById('wrongBtn')?.addEventListener('click', function() {
    if (wrongIndex >= 0) {
      probabilities[wrongIndex] = 0;
      var sum = probabilities.reduce(function(a, b) { return a + b; }, 0);
      probabilities = sum > 0 ? probabilities.map(function(p) { return p / sum; }) : allDishes.map(function() { return 1 / allDishes.length; });
      wrongIndex = -1;
      gameOver = false;
      document.getElementById('guessBox').style.display = 'none';
      var gameArea = document.getElementById('gameArea');
      if (gameArea) {
        var inputs = gameArea.querySelectorAll('button, input');
        for (var i = 0; i < inputs.length; i++) inputs[i].disabled = false;
      }
      askNext();
    }
  });

  var quickBtns = document.querySelectorAll('.quick-btn');
  for (var i = 0; i < quickBtns.length; i++) {
    quickBtns[i].addEventListener('click', function() { handleAnswer(this.dataset.ans); });
  }

  document.getElementById('answerBtn')?.addEventListener('click', function() {
    var input = document.getElementById('customAnswer');
    if (!input) return;
    var val = input.value.toLowerCase().trim();
    if (!val) return;
    if (['yes','yeah','sure','yep','spicy','hot','veg','vegetarian','rice','gravy','curry','sweet','dessert','north','south','chicken','mutton','fish','egg'].some(function(w) { return val.indexOf(w) >= 0; })) {
      handleAnswer('yes');
    } else if (['no','nope','not','neither','nah','n','none'].some(function(w) { return val.indexOf(w) >= 0; })) {
      handleAnswer('no');
    } else {
      handleAnswer('maybe');
    }
    input.value = '';
  });

  document.getElementById('customAnswer')?.addEventListener('keydown', function(e) {
    if (e.key === 'Enter') document.getElementById('answerBtn')?.click();
  });

  document.getElementById('aiChatSend')?.addEventListener('click', aiChatSend);
  document.getElementById('aiChatInput')?.addEventListener('keydown', function(e) {
    if (e.key === 'Enter') aiChatSend();
  });

  var dishCount = document.getElementById('dishCount');
  if (dishCount && window.__AKINATOR_TOTAL) {
    dishCount.textContent = window.__AKINATOR_TOTAL + ' dishes';
  }

  startNewGame();
});
