<?php
require_once __DIR__ . '/config.php';

function curlFetch($url, $token = null) {
  if (function_exists('curl_init')) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 15);
    curl_setopt($ch, CURLOPT_USERAGENT, 'SmakAI/1.0');
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    $headers = ['Accept: application/json'];
    if ($token) {
      $headers[] = "Authorization: token $token";
      curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');
    }
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    $result = curl_exec($ch);
    $info = curl_getinfo($ch);
    curl_close($ch);
    if ($info['http_code'] >= 200 && $info['http_code'] < 300) {
      return $result;
    }
  }
  if (!$token && function_exists('file_get_contents') && ini_get('allow_url_fopen')) {
    $ctx = stream_context_create(['http' => ['timeout' => 15, 'user_agent' => 'SmakAI/1.0']]);
    return @file_get_contents($url, false, $ctx);
  }
  return null;
}

function loadMenuFromGist() {
  $cacheFile = __DIR__ . '/../data/menu-cache.json';
  $cacheMeta = __DIR__ . '/../data/menu-cache-meta.json';
  $localFile = __DIR__ . '/../data/menu.json';
  $meta = [];
  if (file_exists($cacheMeta)) {
    $meta = json_decode(@file_get_contents($cacheMeta), true) ?: [];
  }
  $cacheAge = isset($meta['cached_at']) ? time() - $meta['cached_at'] : 9999;
  $needsRefresh = $cacheAge > 300;

  if (!$needsRefresh && file_exists($cacheFile)) {
    $data = json_decode(@file_get_contents($cacheFile), true);
    if ($data) return $data;
  }

  // Try Gist
  $raw = curlFetch(GIST_URL);
  if ($raw) {
    $data = json_decode($raw, true);
    if ($data && isset($data['menu'])) {
      @file_put_contents($cacheFile, $raw, LOCK_EX);
      @file_put_contents($cacheMeta, json_encode(['cached_at' => time()], JSON_PRETTY_PRINT), LOCK_EX);
      return $data;
    }
  }

  // Fall back to cache file (even if stale)
  if (file_exists($cacheFile)) {
    $data = json_decode(@file_get_contents($cacheFile), true);
    if ($data) return $data;
  }

  // Final fallback: local data/menu.json (the embedded full copy)
  if (file_exists($localFile)) {
    $data = json_decode(@file_get_contents($localFile), true);
    if ($data && isset($data['menu'])) {
      // Seed the cache for next time
      @file_put_contents($cacheFile, json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE), LOCK_EX);
      @file_put_contents($cacheMeta, json_encode(['cached_at' => time()], JSON_PRETTY_PRINT), LOCK_EX);
      return $data;
    }
  }

  return null;
}

function updateGist($menuData) {
  $gistContent = json_encode($menuData, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
  $payload = json_encode([
    'files' => ['menu.json' => ['content' => $gistContent]]
  ]);
  if (function_exists('curl_init')) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, GIST_API);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 30);
    curl_setopt($ch, CURLOPT_USERAGENT, 'SmakAI/1.0');
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'PATCH');
    curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
      'Accept: application/json',
      'Authorization: token ' . GH_TOKEN,
      'Content-Type: application/json'
    ]);
    $result = curl_exec($ch);
    $info = curl_getinfo($ch);
    curl_close($ch);
    if ($info['http_code'] >= 200 && $info['http_code'] < 300) {
      $cacheFile = __DIR__ . '/../data/menu-cache.json';
      @file_put_contents($cacheFile, $gistContent, LOCK_EX);
      @file_put_contents(__DIR__ . '/../data/menu-cache-meta.json',
        json_encode(['cached_at' => time()], JSON_PRETTY_PRINT), LOCK_EX);
      return true;
    }
  }
  return false;
}

function forceRefreshMenu() {
  $cacheFile = __DIR__ . '/../data/menu-cache.json';
  $cacheMeta = __DIR__ . '/../data/menu-cache-meta.json';
  if (file_exists($cacheFile)) @unlink($cacheFile);
  if (file_exists($cacheMeta)) @unlink($cacheMeta);
  return loadMenuFromGist();
}

function getAllDishes($menuData) {
  $dishes = [];
  foreach ($menuData['menu']['categories'] ?? [] as $cat) {
    foreach ($cat['items'] ?? [] as $item) {
      $item['category_name'] = $cat['name'];
      $item['category_id'] = $cat['id'];
      $dishes[] = $item;
    }
  }
  return $dishes;
}

function getMenuSummary($menuData, $maxCats = 10, $maxItemsPerCat = 15) {
  $text = '';
  $catCount = 0;
  foreach ($menuData['menu']['categories'] ?? [] as $cat) {
    if ($catCount >= $maxCats) break;
    if ($catCount > 0) $text .= "\n";
    $text .= "=== " . $cat['name'] . " ===\n";
    $itemCount = 0;
    foreach ($cat['items'] ?? [] as $item) {
      if ($itemCount >= $maxItemsPerCat) break;
      if ($itemCount > 0) $text .= "\n";
      $veg = !empty($item['is_vegetarian']) ? 'Veg' : 'Non-Veg';
      $text .= "- {$item['name']} (₹{$item['price']}, {$item['spice_level']}, {$veg}, {$item['region']})";
      $itemCount++;
    }
    $catCount++;
  }
  return $text;
}
