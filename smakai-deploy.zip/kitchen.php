<?php
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/helpers.php';
require_once __DIR__ . '/includes/menu-loader.php';
$tableNum = $_SESSION['table'] ?? 0;
$stream = getStreamConfig();

// Always show an iframe — real stream if configured, demo video otherwise
$demoUrl = 'https://www.youtube.com/embed/woiO3gMnRk4?autoplay=1&mute=1';
$embedSrc = $stream['video_on'] ? $stream['embed_url'] : $demoUrl;
$isLive = $stream['video_on'];

require_once __DIR__ . '/includes/header.php';
?>
<main class="max-w-5xl mx-auto px-4 pb-12">
  <div class="text-center mb-6 pt-4">
    <h1 class="text-4xl font-bold" style="color:#2D3436;">📺 <span style="color:#4ECDC4;">Live Kitchen</span></h1>
    <?php if ($tableNum > 0): ?>
    <p class="text-gray-500 mt-2">Table #<?= $tableNum ?></p>
    <?php endif; ?>
    <p class="text-xs text-gray-400 mt-1" id="kitchenStatus"><?= $isLive ? '🔴 LIVE' : '⏸️ Demo' ?></p>
  </div>

  <div class="glass-card overflow-hidden mb-4">
    <div class="relative" style="padding-top:56.25%;background:#1a1a2e;min-height:350px;">
      <iframe id="kitchenIframe" src="<?= htmlspecialchars($embedSrc) ?>" class="absolute inset-0 w-full h-full" allow="autoplay; encrypted-media; picture-in-picture; fullscreen" allowfullscreen style="border:0;z-index:1;"></iframe>
      <div id="streamLoading" class="absolute inset-0 flex flex-col items-center justify-center" style="background:#1a1a2e;z-index:2;">
        <div class="w-12 h-12 border-4 border-gray-600 border-t-[#4ECDC4] rounded-full animate-spin mb-3"></div>
        <p class="text-gray-400 text-sm"><?= $isLive ? 'Connecting to live stream...' : 'Loading video...' ?></p>
      </div>
      <div id="liveBadge" class="absolute top-3 left-3 flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-bold z-10" style="display:none;background:rgba(220,38,38,0.9);color:#fff;">
        <span class="w-2 h-2 bg-white rounded-full animate-pulse"></span> LIVE
      </div>
      <div id="demoBadge" class="absolute bottom-3 right-3 flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-bold z-10" style="<?= $isLive ? 'background:rgba(22,163,74,0.85);color:#fff;' : 'background:rgba(0,0,0,0.6);color:#fff;' ?>">
        <span class="w-2 h-2 rounded-full <?= $isLive ? 'bg-green-400 animate-pulse' : 'bg-yellow-400' ?>"></span>
        <?= $isLive ? 'Live Stream' : 'Demo — Set in Admin →' ?>
      </div>
    </div>
  </div>

  <div class="flex gap-3 justify-center flex-wrap">
    <a href="/talk.php" class="btn-bouncy btn-secondary px-6 py-3 no-underline text-sm">💬 Chat with Restaurant</a>
    <a href="/menu.php" class="btn-bouncy btn-outline px-6 py-3 no-underline text-sm">📋 Browse Menu</a>
    <a href="/checkout.php" class="btn-bouncy px-6 py-3 no-underline text-sm" style="background:#FF6B6B;color:#fff;">🛒 View Cart</a>
  </div>
</main>

<script>
(function() {
  var iframe = document.getElementById('kitchenIframe');
  var loading = document.getElementById('streamLoading');
  var liveBadge = document.getElementById('liveBadge');
  var statusEl = document.getElementById('kitchenStatus');

  function hideLoading() {
    if (loading) loading.style.display = 'none';
    if (liveBadge && <?= $isLive ? 'true' : 'false' ?>) liveBadge.style.display = 'flex';
    if (statusEl) statusEl.textContent = '<?= $isLive ? '🔴 LIVE' : '⏸️ Demo' ?>';
  }

  if (iframe) {
    iframe.addEventListener('load', hideLoading);
    iframe.addEventListener('error', hideLoading);
    setTimeout(hideLoading, 8000);
  } else {
    hideLoading();
  }

  // Auto-refresh when admin toggles stream
  var lastUpdated = '';
  setInterval(function() {
    var url = '/admins/stream-status.php' + (lastUpdated ? '?since=' + encodeURIComponent(lastUpdated) : '');
    fetch(url, { credentials: 'same-origin' })
      .then(function(r) { return r.json(); })
      .then(function(d) {
        if (d.last_updated) lastUpdated = d.last_updated;
        if (d.reload) location.reload();
      })
      .catch(function() {});
  }, 6000);
})();
</script>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
