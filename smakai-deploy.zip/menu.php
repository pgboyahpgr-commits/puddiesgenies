<?php
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/menu-loader.php';
$menuData = loadMenuFromGist();
$allCategories = $menuData['menu']['categories'] ?? [];
?>
<main class="max-w-6xl mx-auto px-4 pb-24">
  <div class="text-center mb-6 pt-2">
    <h1 class="text-4xl font-bold" style="color:#2D3436;">📋 <span style="color:#FF6B6B;">Menu</span></h1>
    <p class="text-gray-500 mt-1 text-sm">Fresh · Seasonal · Crafted with care</p>
  </div>

  <div class="relative mb-4 max-w-xl mx-auto">
    <input type="text" id="searchInput" placeholder="Search dishes, ingredients, categories..." class="w-full px-5 py-3.5 pl-12 rounded-2xl border-2 border-gray-200 bg-white/80 outline-none focus:border-[#FF6B6B] transition text-sm shadow-sm" />
    <span class="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 text-lg">🔍</span>
    <button id="clearSearch" class="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600 text-lg hidden" style="background:none;border:none;cursor:pointer;">✕</button>
  </div>

  <div id="categoryTabs" class="flex gap-2 overflow-x-auto pb-2 mb-4 scrollbar-hide"></div>

  <div id="menuContent">
    <?php if (empty($allCategories)): ?>
    <div class="text-center py-16 text-gray-400"><div class="text-5xl mb-3">📋</div><div class="font-bold text-lg">Menu not available</div><div class="text-sm mt-1">Please check back later</div></div>
    <?php else: ?>
    <?php foreach ($allCategories as $cat): $items = $cat['items'] ?? []; ?>
    <div class="menu-section" data-cat-id="<?= htmlspecialchars($cat['id'] ?? '') ?>">
      <div class="menu-section-header"><h2><?= htmlspecialchars($cat['name'] ?? '') ?> <span class="badge"><?= count($items) ?> item<?= count($items) !== 1 ? 's' : '' ?></span></h2></div>
      <?php if (!empty($cat['description'])): ?><p class="text-sm text-gray-400 mb-3"><?= htmlspecialchars($cat['description']) ?></p><?php endif; ?>
      <div class="dish-grid">
        <?php foreach ($items as $item): 
          $price = intval($item['price'] ?? 0);
          $dishId = $item['id'] ?? 'i_' . time() . '_' . rand(100,999);
          $dishName = htmlspecialchars($item['name'] ?? '');
          $dishDesc = htmlspecialchars($item['description'] ?? '');
          $dishImage = htmlspecialchars($item['image'] ?? '');
          $dishSpice = htmlspecialchars($item['spice_level'] ?? '');
          $dishRegion = htmlspecialchars($item['region'] ?? '');
          $isVeg = !empty($item['is_vegetarian']);
          $isPop = !empty($item['popular']);
        ?>
        <div class="dish-card"
          data-dish-id="<?= $dishId ?>"
          data-dish-name="<?= $dishName ?>"
          data-dish-price="<?= $price ?>"
          data-dish-image="<?= $dishImage ?>"
          data-category="<?= htmlspecialchars($cat['id'] ?? '') ?>">
          <div class="dish-img" data-dish="<?= $dishName ?>">
            <?php if ($item['image'] ?? ''): ?>
            <img src="<?= $dishImage ?>" alt="<?= $dishName ?>" loading="lazy" />
            <?php else: ?>
            <span style="font-size:1.8rem;">🍽️</span>
            <?php endif; ?>
          </div>
          <div class="dish-info">
            <div class="dish-name"><?= $dishName ?> <?= $isVeg ? '<span class="veg-badge">🥬</span>' : '<span class="veg-badge">🍗</span>' ?> <?= $isPop ? '<span class="pop-badge">⭐ Popular</span>' : '' ?></div>
            <?php if ($dishDesc): ?><div class="dish-desc"><?= $dishDesc ?></div><?php endif; ?>
            <div class="dish-tags">
              <?php if ($dishSpice): ?><span class="dish-tag">🌶️ <?= $dishSpice ?></span><?php endif; ?>
              <?php if ($dishRegion): ?><span class="dish-tag">📍 <?= $dishRegion ?></span><?php endif; ?>
            </div>
          </div>
          <div class="dish-right">
            <div class="dish-price">₹<?= $price ?></div>
            <button class="dish-add-btn" title="Add <?= $dishName ?>">+</button>
          </div>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
    <?php endforeach; ?>
    <?php endif; ?>
  </div>
</main>

<style>
.scrollbar-hide::-webkit-scrollbar { display: none; }
.scrollbar-hide { -ms-overflow-style: none; scrollbar-width: none; }
.cat-tab {
  white-space: nowrap; padding: 0.5rem 1.2rem; border-radius: 100px; font-size: 0.85rem; font-weight: 600;
  cursor: pointer; transition: all 0.2s; border: 1.5px solid #e5e5e5; background: rgba(255,255,255,0.6); color: #666;
  flex-shrink: 0;
}
.cat-tab:hover { border-color: #FF6B6B; color: #FF6B6B; }
.cat-tab.active { background: #FF6B6B; color: #fff; border-color: #FF6B6B; }
.menu-section { scroll-margin-top: 1rem; }
.menu-section-header {
  display: flex; align-items: center; justify-content: space-between;
  padding: 0.8rem 0; margin-bottom: 0.5rem;
  border-bottom: 3px solid #FFE66D;
}
.menu-section-header h2 { font-family: 'Fredoka', sans-serif; font-size: 1.4rem; font-weight: 600; color: #2D3436; display: flex; align-items: center; gap: 0.5rem; }
.menu-section-header .badge { font-size: 0.7rem; font-weight: 500; background: #FFE66D; color: #5a4e3e; padding: 0.1rem 0.7rem; border-radius: 100px; }
.dish-grid { display: grid; grid-template-columns: 1fr; gap: 0.7rem; }
@media (min-width: 640px) { .dish-grid { grid-template-columns: 1fr 1fr; } }
@media (min-width: 1024px) { .dish-grid { grid-template-columns: 1fr 1fr 1fr; } }
.dish-card {
  display: flex; align-items: center; gap: 0.8rem;
  background: rgba(255,255,255,0.7); backdrop-filter: blur(8px);
  border: 1px solid rgba(255,255,255,0.3); border-radius: 16px;
  padding: 0.8rem; box-shadow: 0 2px 12px rgba(0,0,0,0.04);
  transition: transform 0.2s, box-shadow 0.2s;
}
.dish-card:hover { transform: translateY(-2px); box-shadow: 0 6px 24px rgba(0,0,0,0.08); }
.dish-card:active { transform: scale(0.98); }
.dish-img { width: 72px; height: 72px; border-radius: 12px; overflow: hidden; background: #f0ede7; flex-shrink: 0; display: flex; align-items: center; justify-content: center; font-size: 1.8rem; }
.dish-img img { width: 100%; height: 100%; object-fit: cover; }
.dish-info { flex: 1; min-width: 0; }
.dish-info .dish-name { font-weight: 600; color: #2D3436; font-size: 0.95rem; display: flex; align-items: center; gap: 0.4rem; flex-wrap: wrap; }
.dish-info .dish-name .veg-badge { font-size: 0.7rem; }
.dish-info .dish-name .pop-badge { font-size: 0.65rem; background: #FFE66D; padding: 0.05rem 0.5rem; border-radius: 100px; }
.dish-info .dish-desc { font-size: 0.75rem; color: #999; margin-top: 0.1rem; line-height: 1.3; }
.dish-tags { display: flex; gap: 0.25rem; flex-wrap: wrap; margin-top: 0.2rem; }
.dish-tag { font-size: 0.65rem; color: #888; background: #f0ede7; padding: 0.05rem 0.5rem; border-radius: 100px; white-space: nowrap; }
.dish-right { display: flex; flex-direction: column; align-items: flex-end; gap: 0.4rem; flex-shrink: 0; }
.dish-price { font-weight: 700; color: #2D3436; background: #FFE66D; padding: 0.15rem 0.8rem; border-radius: 100px; font-size: 0.9rem; white-space: nowrap; }
.dish-add-btn {
  width: 34px; height: 34px; border-radius: 50%; border: none;
  background: #4ECDC4; color: #fff; font-size: 1.2rem; font-weight: 700;
  cursor: pointer; transition: transform 0.2s, background 0.15s;
  display: flex; align-items: center; justify-content: center; line-height: 1;
}
.dish-add-btn:hover { transform: scale(1.15); background: #FF6B6B; }
.dish-add-btn:active { transform: scale(0.9); }
.dish-add-btn.added { background: #4ECDC4; transform: scale(1.2); }
.search-highlight { background: #FFE66D; padding: 0 0.2rem; border-radius: 4px; }
.no-results { text-align: center; padding: 3rem 1rem; color: #999; }
.no-results .icon { font-size: 3rem; margin-bottom: 0.5rem; }
</style>

<script>
(function() {
  var searchInput = document.getElementById('searchInput');
  var clearBtn = document.getElementById('clearSearch');
  var tabs = document.getElementById('categoryTabs');
  var sections = document.querySelectorAll('.menu-section');
  var allCards = document.querySelectorAll('.dish-card');
  var searchTerm = '';
  var activeCategory = null;

  function getCategories() {
    var cats = [];
    sections.forEach(function(s) {
      var id = s.dataset.catId;
      var name = s.querySelector('.menu-section-header h2')?.textContent?.trim() || id;
      if (id) cats.push({ id: id, name: name });
    });
    return cats;
  }

  function renderTabs() {
    var cats = getCategories();
    tabs.innerHTML = '<div class="cat-tab active" data-cat="">All</div>';
    cats.forEach(function(c) {
      tabs.innerHTML += '<div class="cat-tab" data-cat="' + c.id.replace(/"/g,'&quot;') + '">' + c.name.replace(/"/g,'&quot;') + '</div>';
    });
    tabs.querySelectorAll('.cat-tab').forEach(function(t) {
      t.addEventListener('click', function() {
        tabs.querySelectorAll('.cat-tab').forEach(function(x) { x.classList.remove('active'); });
        this.classList.add('active');
        activeCategory = this.dataset.cat;
        filterDishes();
      });
    });
  }

  function filterDishes() {
    var term = searchTerm.toLowerCase().trim();
    var hasResults = false;

    sections.forEach(function(section) {
      var catId = section.dataset.catId;
      var catMatch = !activeCategory || catId === activeCategory;
      var cards = section.querySelectorAll('.dish-card');
      var visibleCount = 0;

      cards.forEach(function(card) {
        var name = (card.dataset.dishName || '').toLowerCase();
        var desc = (card.querySelector('.dish-desc')?.textContent || '').toLowerCase();
        var match = (!term || name.indexOf(term) >= 0 || desc.indexOf(term) >= 0);
        var show = match && catMatch;
        card.style.display = show ? '' : 'none';
        if (show) visibleCount++;
      });

      var header = section.querySelector('.menu-section-header');
      var desc = section.querySelector('.menu-section-header + p');
      var grid = section.querySelector('.dish-grid');
      var sectionVisible = catMatch && (!term || visibleCount > 0);
      section.style.display = sectionVisible ? '' : 'none';
      if (sectionVisible) hasResults = true;
    });

    var existing = document.querySelector('.no-results');
    if (!hasResults && !existing) {
      var div = document.createElement('div');
      div.className = 'no-results';
      div.innerHTML = '<div class="icon">😕</div><div class="font-bold text-lg">No dishes found</div><div class="text-sm mt-1">Try a different search term</div>';
      document.getElementById('menuContent').appendChild(div);
    } else if (hasResults && existing) {
      existing.remove();
    }

    // Upgrade dish images after filter
    setTimeout(function() {
      document.querySelectorAll('.dish-img[data-dish]').forEach(function(el) {
        if (el.closest('.dish-card')?.style.display !== 'none') {
          var img = el.querySelector('img');
          if (img && typeof upgradeDishImage === 'function') upgradeDishImage(el.dataset.dish, img);
        }
      });
    }, 200);
  }

  searchInput.addEventListener('input', function() {
    searchTerm = this.value;
    clearBtn.classList.toggle('hidden', !searchTerm);
    activeCategory = null;
    tabs.querySelectorAll('.cat-tab').forEach(function(t) { t.classList.remove('active'); });
    var at = tabs.querySelector('.cat-tab:first-child');
    if (at) at.classList.add('active');
    filterDishes();
  });

  clearBtn.addEventListener('click', function() {
    searchInput.value = '';
    searchTerm = '';
    clearBtn.classList.add('hidden');
    filterDishes();
  });

  // Handle search param
  var params = new URLSearchParams(window.location.search);
  var searchParam = params.get('search');
  if (searchParam) {
    searchInput.value = searchParam;
    searchTerm = searchParam;
    clearBtn.classList.remove('hidden');
  }

  renderTabs();
  filterDishes();

  if (searchParam) {
    setTimeout(function() {
      var fc = document.querySelector('.dish-card[style*="display: block"], .dish-card:not([style*="display: none"])');
      if (fc) fc.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }, 300);
  }
})();
</script>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
